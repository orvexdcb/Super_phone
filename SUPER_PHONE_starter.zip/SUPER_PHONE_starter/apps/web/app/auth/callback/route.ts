import { NextResponse, type NextRequest } from "next/server";
import { createServerSupabase } from "../../../lib/supabase-server";
import { safeNext } from "../../../lib/safe-next";

// يستقبل رابط تأكيد البريد ويحوّله إلى جلسة
export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = safeNext(searchParams.get("next"));
  if (code) {
    const supabase = await createServerSupabase();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(`${origin}${next}`);
  }
  return NextResponse.redirect(`${origin}/login`);
}
