import React, { useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { supabase } from '../lib/supabase';
import { COLORS } from '../lib/constants';

export default function AuthScreen() {
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  async function submit() {
    setError(''); setInfo('');
    if (!email.trim() || !password) return setError('أدخل البريد وكلمة المرور.');
    if (mode === 'signup' && password.length < 8) return setError('كلمة المرور يجب ألا تقل عن 8 أحرف.');
    setBusy(true);
    if (mode === 'login') {
      const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (err) setError('البريد أو كلمة المرور غير صحيحة.');
    } else {
      const { data, error: err } = await supabase.auth.signUp({
        email: email.trim(), password, options: { data: { full_name: name.trim() } },
      });
      if (err) setError('تعذّر إنشاء الحساب. تحقق من البيانات أو جرّب بريداً آخر.');
      else if (!data.session) setInfo('أرسلنا رابط تأكيد إلى بريدك. أكّد ثم سجّل الدخول.');
    }
    setBusy(false);
  }

  return (
    <View style={styles.wrap}>
      <Text style={styles.h1}>{mode === 'login' ? 'تسجيل الدخول' : 'إنشاء حساب'}</Text>
      {mode === 'signup' && (
        <TextInput style={styles.input} placeholder="الاسم" value={name} onChangeText={setName} textAlign="right" maxLength={80} />
      )}
      <TextInput style={styles.input} placeholder="البريد الإلكتروني" value={email} onChangeText={setEmail}
        autoCapitalize="none" keyboardType="email-address" autoComplete="email" />
      <TextInput style={styles.input} placeholder="كلمة المرور" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" />
      <Pressable style={[styles.btn, busy && { opacity: 0.6 }]} onPress={submit} disabled={busy}>
        {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>{mode === 'login' ? 'دخول' : 'إنشاء الحساب'}</Text>}
      </Pressable>
      {!!error && <Text style={styles.err}>{error}</Text>}
      {!!info && <Text style={styles.ok}>{info}</Text>}
      <Pressable onPress={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); setInfo(''); }}>
        <Text style={styles.alt}>{mode === 'login' ? 'ليس لديك حساب؟ أنشئ حساباً' : 'لديك حساب؟ سجّل الدخول'}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { padding: 24, gap: 10 },
  h1: { fontSize: 22, fontWeight: '700', textAlign: 'center', marginBottom: 8, color: COLORS.text },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#cfd8d3', borderRadius: 10, padding: 12, fontSize: 16 },
  btn: { backgroundColor: COLORS.green, borderRadius: 10, padding: 14, alignItems: 'center' },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  err: { color: COLORS.danger, textAlign: 'center' },
  ok: { color: COLORS.green, textAlign: 'center' },
  alt: { color: COLORS.green, textAlign: 'center', marginTop: 12 },
});
